package com.example.practicejava;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "find_all_persons" , query ="select p from Person p")
public class Person {
	
 @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
 private Integer id;
  private String name;
  private String location;
  private String birthDate;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
@Override
public String toString() {
	return String.format("\n  persons are  ::   name = %s , id = %s , location = %s , birthdate = %s ", name,id,location,birthDate);
}
public String getBirthDate() {
	return birthDate;
}
public void setBirthDate(String birthDate) {
	this.birthDate = birthDate;
}
public Person(int id, String name, String location, String birthDate) {
	super();
	this.id = id;
	this.name = name;
	this.location = location;
	this.birthDate = birthDate;
}


public Person( String name, String location, String birthDate) {
	super();
	this.name = name;
	this.location = location;
	this.birthDate = birthDate;
}

  
  public Person() {
	  
  }
  

}
