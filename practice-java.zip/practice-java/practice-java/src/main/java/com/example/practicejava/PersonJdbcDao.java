/*
 * package com.example.practicejava;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.jdbc.core.BeanPropertyRowMapper; import
 * org.springframework.jdbc.core.JdbcTemplate; import
 * org.springframework.stereotype.Repository;
 * 
 * @Repository public class PersonJdbcDao {
 * 
 * //select * from person
 * 
 * 
 * @Autowired JdbcTemplate jdbcTemplate;
 * 
 * 
 * public java.util.List<User> findAll(){
 * 
 * return jdbcTemplate.query("select * from user", new
 * BeanPropertyRowMapper<User>(User.class));
 * 
 * }
 * 
 * public User findOne(int id){
 * 
 * 
 * return jdbcTemplate.queryForObject ("select * from user where id = ? ", new
 * Object[] {id}, new BeanPropertyRowMapper<User>(User.class));
 * 
 * }
 * 
 * public int insertById(User p) {
 * 
 * 
 * return
 * jdbcTemplate.update("insert into user (name , email , id) values(?,?,?) ",
 * new Object[] {p.getName(), p.getEmail(),p.getId()});
 * 
 * 
 * } }
 */