package com.example.practicejava;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class PersonJpaRepository {
	private org.jboss.logging.Logger logger =LoggerFactory.logger(PersonJpaRepository.class);

	
	//connect to database through EntityManager
	@PersistenceContext
	EntityManager entityManager;
	
	
	public Person findById(int id) {
		
		return entityManager.find(Person.class, id);
		
		
	}
	
	public Person update(Person person) {
		
		return entityManager.merge(person);
		
	}
	
	public void deleteById(int id)
	{
		Person person = findById(id);
		entityManager.remove(person);
		logger.info("deleted person is "  +  person.toString());
			}
	
   public java.util.List<Person>  findAll(){
	   
	   return entityManager.createNamedQuery("find_all_persons",Person.class).getResultList();
	   
	   
	   
	   
   }
}
