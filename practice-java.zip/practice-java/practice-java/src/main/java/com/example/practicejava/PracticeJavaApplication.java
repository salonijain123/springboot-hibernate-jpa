package com.example.practicejava;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.practicejava.jdbc.CourseRepository;
import com.example.practicejava.jdbc.EmployeeRepository;
import com.example.practicejava.jdbc.StudentRepository;
//spring context file
//controller registered as a bean and managed 
@SpringBootApplication
public class PracticeJavaApplication  implements CommandLineRunner  {
	private org.jboss.logging.Logger logger =LoggerFactory.logger(PracticeJavaApplication.class);

	
	@Autowired
	StudentRepository studentRepository;
	 
	
	
	
	
	@Autowired
	CourseRepository courseRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	 
	public static void main(String[] args) {
		SpringApplication.run(PracticeJavaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		/*
		 * List<Review> reList= new ArrayList<>(); Review review1 =new
		 * Review("new rev1", "newRev1"); Review review = new Review("newRev2",
		 * "newRev2"); reList.add(review); reList.add(review1);
		 * 
		 * courseRepository.addReviewsForCourseGenericMethod(1L, reList);
		 * 
		 * 
		 */
	
		//studentRepository.someOperation();
	 
		

		/*
		 * employeeRepository.insert(new FullTimeEmployee("Jack", new
		 * BigDecimal("10000"))); employeeRepository.insert(new PartTimeEmployee("Jill",
		 * new BigDecimal("50")));
		 * 
		 * logger.infof("all part time employess  {}",employeeRepository.
		 * retrieveAllFullTimeEmployees());
		 * logger.infof("all  full time employess  {}",employeeRepository.
		 * retrieveAllPartTimeEmployees());
		 */

		
		
	}

	
	 
	 

}
