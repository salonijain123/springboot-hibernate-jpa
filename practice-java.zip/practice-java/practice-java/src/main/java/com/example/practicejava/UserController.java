/*
 * package com.example.practicejava;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * @RestController
 * 
 * public class UserController {
 * 
 * @Autowired userService userService;
 * 
 * 
 * @GetMapping("/book/{bookid}") private User getBooks(@PathVariable("bookid")
 * int bookid) {
 * 
 * return userService.getBooksById(bookid); }
 * 
 * }
 */