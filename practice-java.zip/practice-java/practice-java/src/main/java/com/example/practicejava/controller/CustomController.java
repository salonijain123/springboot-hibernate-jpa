package com.example.practicejava.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.practicejava.Person;
import com.example.practicejava.PersonJpaRepository;

@RestController
public class CustomController {
 
	@Autowired
	PersonJpaRepository personJpaRepo;
	
    @RequestMapping(value = "/custom", method = RequestMethod.POST)
    public String custom() {
        return "sbAppGet";
    }
    
    @RequestMapping(value = "/custom/Person", method = RequestMethod.GET)
    public Person findById(@RequestParam("id")  int id) {
    	
    	Person person=	personJpaRepo.findById(id);
    	if(person !=null)
    	{
    	
		return person;
    	
    	
    	
    }
    	else{
    		
    	
     throw new ArithmeticException();
    	}
    	}
    
}