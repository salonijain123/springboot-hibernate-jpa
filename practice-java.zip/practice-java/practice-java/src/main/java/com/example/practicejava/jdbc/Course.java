package com.example.practicejava.jdbc;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity

public class Course {
	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	
	@OneToMany(mappedBy = "course",fetch =FetchType.LAZY)
	private java.util.List<Review> reviews = new ArrayList<>();
	
	
	@ManyToMany(mappedBy = "courses")
	private java.util.List<Student> students = new ArrayList<>();
	
	
	
	public java.util.List<Student> getStudents() {
		return students;
	}

	public void addStudents(Student student) {
		this.students.add(student);
	}

	protected Course() {}

	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + "]";
	}

	public Course(String name) {
		super();
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public java.util.List<Review> getReviews() {
		return reviews;
	}

	public void setReviews(java.util.List<Review> reviews) {
		this.reviews = reviews;
	}
	
	public void addReview(Review review) {
		
		this.reviews.add(review);
		
	}
	
	public void removeReview(Review review) {
		
		this.reviews.remove(review);
	}
	
	
	

}
