package com.example.practicejava.jdbc;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Review {
	
	@Id
	@GeneratedValue
	private Long id;
	
   private String decription;
   
   private String rating;
   
   public Review() {
	super();
	// TODO Auto-generated constructor stub
}

@ManyToOne(fetch = FetchType.LAZY)
   private Course course;

public Course getCourse() {
	return course;
}

public void setCourse(Course course) {
	this.course = course;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getDecription() {
	return decription;
}

public void setDecription(String decription) {
	this.decription = decription;
}

public String getRating() {
	return rating;
}

public void setRating(String rating) {
	this.rating = rating;
}

@Override
public String toString() {
	return "Review [id=" + id + ", decription=" + decription + ", rating=" + rating + "]";
}

public Review(String decription, String rating) {
	super();
	this.decription = decription;
	this.rating = rating;
}
   
   
   
	

}
