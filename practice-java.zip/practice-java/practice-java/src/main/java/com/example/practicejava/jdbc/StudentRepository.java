package com.example.practicejava.jdbc;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class StudentRepository {
	private org.jboss.logging.Logger logger = LoggerFactory.logger(StudentRepository.class);

	@Autowired
	EntityManager em;

	public Student findById(Long id) {
		Student student = em.find(Student.class, id);
		logger.info("student {}" + student);
		return student;
	}

	@Transactional
	public Student save(Student student) {

		if (student.getId() == null) {
			em.persist(student);
		} else {
			em.merge(student);
		}

		return student;
	}

	public void deleteById(Long id) {
		Student student = findById(id);
		em.remove(student);
	}

	public void playWithEm() {

		Student student = new Student("d1");
		Student student2 = new Student("d2");
		em.persist(student2);

		em.persist(student);
		em.flush();

		student2.setName("d3");
		em.refresh(student2);
		em.flush();

	}

	@Transactional
	public void saveWithPassport() {

		Passport passport = new Passport("L12344");
		em.persist(passport);
		Student student1 = new Student("ria");
		student1.setPassport(passport);
		em.persist(student1);
	}

	public void someOperation() {
	
		/*
		 * Passport passport =em.find(Passport.class, 1L); Student student2 =
		 * passport.getStudent();
		 * 
		 * logger.infof("passport {} ", passport); logger.infof("student 2 {} ",
		 * student2);
		 */

		Student student = new Student("rr");
		Course course = new Course(" Steps");
		em.persist(student);
		em.persist(course);
		
		student.addCourses(course);
		course.addStudents(student);
		em.persist(student);
	}

}
