create table person(
id integer not null ,
name VARCHAR(255),
location VARCHAR(255)
PRIMARY KEY(id)

);