package com.example.practicejava;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.practicejava.jdbc.Course;
import com.example.practicejava.jdbc.CourseRepository;
import com.example.practicejava.jdbc.Review;
import com.example.practicejava.jdbc.Student;
import com.example.practicejava.jdbc.StudentRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=PracticeJavaApplication.class)
class PracticeJavaApplicationTests2 {
	
	private org.jboss.logging.Logger logger =LoggerFactory.logger(PracticeJavaApplication.class);

	
	@Autowired
	CourseRepository courseRepository;
	
	@Autowired
	StudentRepository studentRepository;
	
	
	@Autowired
	EntityManager em;

	@Test
	void contextLoads() {
		
		Long bLong=(long) 89;
		Course course= courseRepository.findById(bLong);
		assertEquals("new name2", course.getName());
		
		
	}
	
	@Test
	//@DirtiesContext
	public void save_basic() {
		
		Long bLong=(long) 89;

		Course course =courseRepository.findById(bLong);
		course.setName("new name2");
		if(course !=null) {
			courseRepository.save(course);
			
	}
		
		Course course2 = courseRepository.findById(bLong);
		assertEquals("new name2", course2.getName());
          		
	}
	
	
	//
	
	@Test
	//@DirtiesContext
	public void playWithEm() {
		courseRepository.playWithEm();

		
	}
	
	@Test
	@Transactional
	public void retrieveStudentWithPassport() {
		Student student = em.find(Student.class, 2L);
		logger.infof("student {} ",student);
	String passport=	student.getPassport().getNumber();
		logger.infof("passport {} "  ,passport);

		
	}
	

	//@Test
  //  @Transactional
    //PersistenceContext - all entities are stored
	/*
	 * public void sameTest2() { studentRepository.someOperation();
	 * 
	 * }
	 */
	
	
	@Test
	@Transactional
	
		public void retriveReviewsForCOURSE() {
       Course course = courseRepository.findById(1L);
       logger.infof("course reviews12 are {}  ",course);
		}
	
	

	@Test
	@Transactional
	
		public void retriveCourseForReview() {
      Review  review = em.find(Review.class, 100L);
       logger.infof(" reviews course are12 {}  ",review);
		}
	
	@Test
	@Transactional
	
		public void retrieveStudent() {
   Student student = em.find(Student.class, 1L);
   logger.infof("student's courses are"  + student.getCourses());
		}
	
	@Test
	@Transactional
	public void retrieveCoursesFromStudents() {
   Course course = em.find(Course.class, 3L);
   logger.infof(" students are"  + course.getStudents());
		}
	
	@Test
	@DirtiesContext
	@Transactional
	public void insertStudentAndCourse() {
		
		//studentRepository.someOperation();
	}
	

}
